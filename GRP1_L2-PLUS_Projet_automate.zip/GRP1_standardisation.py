"""Code de LUCAS Elise, OUACHTAR Iman, BALTHAZAR Jérôme,
ETIEVANT Séverin, Fraccaro Xavier,
Groupe n°1, L2-PLUS"""

#importations de nos fonctions
from GRP1_lire_afficher_automate import *


def est_automate_standard(automate):
    init_states = automate['init_states']
    transitions = automate['transitions']
    # Vérifier s'il existe plus d'une entrée
    if len(automate['init_states']) != 1:
        return False

    unique_entree = init_states[0]
    # Vérifier si l'unique entrée a des transitions entrantes
    for transition in transitions:
        if transition[2] == unique_entree:
            return False

    return True

def afficher_standardisation(automate):
    if est_automate_standard(automate):
        print("L'automate est déjà standard.")
        return

    print("L'automate n'est pas standard.")
    reponse = input("Voulez-vous le standardiser ? (o/n) : ")

    if reponse.lower() == 'o':
        standardiser_automate(automate)
        print("\nAutomate standardisé :")
        afficher_tableau_automate(automate)
        afficher_automate(automate)
    else:
        print("Opération annulée.")

def standardiser_automate(automate):
    # Création d'un nouvel état initial 'i'
    nouvel_etat_initial = 'i'
    automate['states'].append(nouvel_etat_initial)

    # Modification des transitions pour le nouvel état initial
    transitions_modifiees = []
    for transition in automate['transitions']:
        if transition[0] in automate['init_states']:
            # Nouvelle transition avec le nouvel état initial
            transitions_modifiees.append((nouvel_etat_initial, transition[1], transition[2]))
    # Ajout des nouvelles transitions au début de la liste de transitions existante
    automate['transitions'] = transitions_modifiees + automate['transitions']
    automate['init_states'] = [nouvel_etat_initial]

    # Mise à jour du nombre d'états
    automate['num_states'] += 1

    # Mise à jour du nombre de transitions
    automate['num_transitions'] += len(transitions_modifiees)


    return automate