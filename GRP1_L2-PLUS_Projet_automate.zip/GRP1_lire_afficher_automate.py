"""Code de LUCAS Elise, OUACHTAR Iman, BALTHAZAR Jérôme,
ETIEVANT Séverin, Fraccaro Xavier,
Groupe n°1, L2-PLUS"""

import matplotlib.pyplot as plt #bibliothèque pour utiliser des fonctions mathématiques
import networkx as nx #bibliothèque pour afficher nos automates
import random
from tabulate import tabulate #bibliothèque pour afficher nos tableaux


def choisir_fichier_texte():
    while True:
        try:
            numero = int(input("Veuillez saisir un nombre entre 0 et 44 : "))
            if 0 <= numero <= 44:
                filename = f"GRP1_automate_{numero}.txt"
                return filename
            else:
                print("Le nombre saisi n'est pas valide. Veuillez saisir un nombre entre 0 et 44.")
        except ValueError:
            print("Veuillez saisir un nombre valide.")

def lire_automate(filename):
    automate = {}
    with open(filename, 'r') as file:
        automate['alphabet_size'] = int(file.readline().strip())
        automate['num_states'] = int(file.readline().strip())
        automate['states'] = [str(state) for state in range(automate['num_states'])]  # Liste de tous les états
        automate['init_states'] = file.readline().strip().split()  # Liste des états initiaux
        automate['terminal_states'] = file.readline().strip().split()  # Liste des états terminaux
        automate['num_transitions'] = int(file.readline().strip())
        automate['transitions'] = []
        for _ in range(automate['num_transitions']):
            # Lire une ligne et enlever les espaces inutiles
            transition_line = file.readline().strip()
            start_state = ''
            symbol = ''
            end_state = ''
            # Parcourir chaque caractère de la ligne
            for char in transition_line:
                # Vérifier si le caractère est un chiffre
                if char.isdigit():
                    # Ajouter le caractère à l'état de départ
                    start_state += char
                else:
                    # Si le caractère n'est pas un chiffre, il s'agit d'une lettre (symbole)
                    symbol = char
                    # Ajouter le reste de la ligne à l'état final
                    end_state = transition_line[len(start_state) + 1:]
                    break
            automate['transitions'].append((start_state, symbol, end_state))
        # Vérifier si la phrase existe déjà dans le fichier
        with open(filename, 'r') as file:
            lines = file.readlines()
            found = False
            for line in lines:
                if "Trace d'exécution, le fichier a bien été chargé" in line:
                    found = True
                    break

        # Si la phrase n'existe pas, l'écrire dans le fichier
        if not found:
            with open(filename, 'a') as file:
                file.write("Trace d'exécution, le fichier a bien été chargé\n")
        afficher_tableau_automate(automate)
        afficher_automate(automate)

    return automate


def afficher_automate(automate):
    alphabet_size = automate['alphabet_size']
    num_states = automate['num_states']
    states = automate['states']
    init_states = automate['init_states']
    terminal_states = automate['terminal_states']
    transitions = automate['transitions']

    # Initialisation du graphe dirigé
    G = nx.DiGraph()

    # Ajout des états
    for state in states:
        G.add_node(state)

    # Ajout des transitions
    for transition in transitions:
        start_state, symbol, end_state = transition
        G.add_edge(start_state, end_state, label=symbol)

    # Positionnement des états dans le graphe
    pos = positionnement_noeuds(G)

    # Création d'un dictionnaire pour stocker les couleurs des noeuds
    node_colors = {state: 'cyan' for state in states}

    # Attribution des couleurs en fonction des états initiaux et terminaux
    for state in init_states:
        node_colors[state] = 'green'

    for state in terminal_states:
        if node_colors[state] == 'green':
            node_colors[state] = 'orange'
        else:
            node_colors[state] = 'red'

    # Affichage des états avec les couleurs définies
    nx.draw_networkx_nodes(G, pos, node_color=[node_colors[state] for state in states], node_size=700)
    nx.draw_networkx_labels(G, pos)

    # Dessin des flèches pour représenter les transitions
    nx.draw_networkx_edges(G, pos, arrowsize=20, connectionstyle="arc3,rad=.1", width=1.5, edge_color='black')

    # Ajout des étiquettes des transitions au-dessus de la flèche
    for edge in G.edges(data=True):
        start_state, end_state, label = edge
        symbol = label['label']
        offset = 0.05 if pos[start_state][0] < pos[end_state][0] else +0.25
        midpoint_x = (pos[start_state][0] + pos[end_state][0]) / 2
        midpoint_y = (pos[start_state][1] + pos[end_state][1]) / 2
        plt.text(midpoint_x, midpoint_y + offset, symbol, fontsize=10, ha='center')
    # Affichage du graphe
    plt.title('Automate Fini')
    plt.axis('off')
    plt.show()



def positionnement_noeuds(graph):
    num_nodes = len(graph.nodes)
    if 1 <= num_nodes <= 20:
        # Positionnement en cercle pour 1 à 20 nœuds
        return nx.circular_layout(graph)
    else:
        # Positionnement aléatoire pour plus de 8 nœuds
        return {node: (random.random(), random.random()) for node in graph.nodes()}


from tabulate import tabulate


def afficher_tableau_automate(automate):
    # Récupération des informations de l'automate
    num_states = automate['num_states']
    states = automate['states']
    init_states = automate['init_states']
    terminal_states = automate['terminal_states']
    transitions = automate['transitions']

    # Création de la liste des symboles de transition
    symbols = set()
    for t in transitions:
        symbols.add(t[1])
    symbols = sorted(list(symbols))

    # Ajouter la lettre 'a' s'il n'est pas déjà présent dans les symboles
    if 'a' not in symbols:
        symbols.append('a')

    # En-tête du tableau
    headers = ["Entrée/Sortie", "État"] + symbols
    data = []

    # Boucle pour ajouter chaque état avec ses transitions dans les données du tableau
    for state in states:
        # Détermination de l'entrée et de la sortie de l'état
        if state in init_states and state in terminal_states:
            inout = "E/S"
        elif state in init_states:
            inout = "E"
        elif state in terminal_states:
            inout = "S"
        else:
            inout = "-"

        # Récupération des transitions sortant de l'état
        state_transitions = {s: [] for s in symbols}
        for t in transitions:
            if str(t[0]) == state:
                state_transitions[t[1]].append(t[2])

        # Ajout des informations de l'état dans les données du tableau
        row = [inout, state]
        for sym in symbols:
            row.append(', '.join(map(str, state_transitions[sym])) if state_transitions[sym] else '-')
        data.append(row)

    # Affichage du tableau
    print(tabulate(data, headers=headers, tablefmt="grid"))

    legend = [
        ["\033[96mCyan (État non particulié)\033[0m"],
        ["\033[92mVert (État initial)\033[0m"],
        ["\033[91mRouge (État terminal)\033[0m"],
        ["\033[93mOrange (État initial et terminal)\033[0m"]
    ]

    print(tabulate(legend, tablefmt="plain"))