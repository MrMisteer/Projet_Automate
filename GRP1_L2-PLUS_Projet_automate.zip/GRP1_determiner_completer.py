"""Code de LUCAS Elise, OUACHTAR Iman, BALTHAZAR Jérôme,
ETIEVANT Séverin, Fraccaro Xavier,
Groupe n°1, L2-PLUS"""

#importations de nos fonctions
from GRP1_lire_afficher_automate import *

def est_automate_deterministe(automate):
    # Vérification du nombre d'entrées
    if len(automate['init_states']) != 1:
        return False

    # Vérification des transitions
    transitions = {}
    for transition in automate['transitions']:
        key = (transition[0], transition[1])
        if key in transitions:
            return False  # Plus d'une flèche sortant d'un même état pour un même caractère
        transitions[key] = transition[2]

    return True


def est_automate_complet(automate):
    alphabet = set(chr(ord('a') + i) for i in range(automate['alphabet_size']))

    for state in automate['states']:
        transitions = {transition[1] for transition in automate['transitions'] if transition[0] == state}

        # Vérifier s'il manque des transitions vers chaque symbole de l'alphabet
        for symbol in alphabet:
            if symbol not in transitions:
                # Si l'état est l'état poubelle, il n'est pas nécessaire d'ajouter une transition manquante
                if state != 'P':
                    return False  # Il manque des transitions pour cet état
    return True


def determiniser_completer_automate(automate):
    if est_automate_deterministe(automate):
        print("L'automate est déjà déterministe.")
        if not est_automate_complet(automate):
            completer = input("L'automate n'est pas complet. Voulez-vous le compléter ? (o/n) : ")
            if completer.lower() == 'o':
                completer_automate(automate)
                afficher_automate(automate)
                print("Automate complété :")
                afficher_tableau_automate(automate)
            else:
                print("Opération annulée.")
        else:
            print("L'automate est déjà complet.")
    else:
        print("L'automate n'est pas déterministe.")
        determiniser = input("Voulez-vous déterminiser l'automate ? (o/n) : ")
        if determiniser.lower() == 'o':
            determiniser_automate(automate)
            afficher_automate(automate)
            print("Automate déterminé :")
            afficher_tableau_automate(automate)
            if not est_automate_complet(automate):
                completer = input("L'automate n'est pas complet. Voulez-vous le compléter ? (o/n) : ")
                if completer.lower() == 'o':
                    completer_automate(automate)
                    afficher_automate(automate)
                    print("Automate complété :")
                    afficher_tableau_automate(automate)
                else:
                    print("Opération annulée.")
            else:
                print("L'automate est complet.")
        else:
            print("Opération annulée.")


def determiniser_automate(automate):
    nouveaux_etats = {}  # Dictionnaire pour mapper les nouveaux états aux anciens ensembles d'états
    nouveaux_transitions = []  # Liste pour stocker les nouvelles transitions
    transitions_traitees = set()  # Ensemble pour stocker les transitions déjà traitées

    # Copie des états terminaux de l'automate d'origine
    etats_terminaux_origine = set(automate['terminal_states'])

    # Fonction pour fusionner les états en un nouvel état
    def fusionner_etats(etats):
        etats = tuple(set(etats))  # Convertir la liste en tuple
        etats = sorted(etats)  # Trier les états pour garantir un résultat unique
        etat_fusionne = ''.join(etats)
        if etat_fusionne not in nouveaux_etats:
            nouveaux_etats[etat_fusionne] = etats
        return etat_fusionne

    # Fonction pour récupérer les transitions sortant d'un ensemble d'états
    def transitions_sortantes(ensemble_etats):
        transitions = {}
        for transition in automate['transitions']:
            if transition[0] in ensemble_etats:
                symbole = transition[1]
                if symbole in transitions:
                    transitions[symbole].append(transition[2])
                else:
                    transitions[symbole] = [transition[2]]
        return transitions

    # Initialisation de l'ensemble des états à traiter avec l'état initial
    etats_a_traiter = [tuple(automate['init_states'])]  # Convertir en tuple
    etats_traites = set()  # Ensemble pour stocker les états déjà traités
    states = [tuple(automate['init_states'])]  # Convertir en tuple
    # Récupérer tous les anciens états initiaux
    anciens_etats_initiaux = automate['init_states']

    # Fusionner tous les anciens états initiaux en un seul état initial
    nouvel_etat_initial = fusionner_etats(anciens_etats_initiaux)

    # Mettre à jour l'automate avec le nouvel état initial
    automate['init_states'] = [nouvel_etat_initial]
    while etats_a_traiter:
        ensemble_etats = etats_a_traiter.pop(0)
        if tuple(ensemble_etats) in etats_traites:
            continue  # Éviter de traiter deux fois le même ensemble d'états
        etats_traites.add(tuple(ensemble_etats))

        nouvel_etat = fusionner_etats(ensemble_etats)
        transitions = transitions_sortantes(ensemble_etats)
        for symbole, etats_suivants in transitions.items():
            nouvel_etat_suivant = fusionner_etats(etats_suivants)
            nouvelle_transition = (nouvel_etat, symbole, nouvel_etat_suivant)
            if nouvelle_transition not in transitions_traitees:
                nouveaux_transitions.append(nouvelle_transition)
                transitions_traitees.add(nouvelle_transition)
            if tuple(etats_suivants) not in etats_traites:
                etats_a_traiter.append(etats_suivants)

    # Mise à jour des états terminaux dans le nouvel automate
    automate['terminal_states'] = []
    for etat, etats in nouveaux_etats.items():
        for etat_terminal in etats_terminaux_origine:
            if etat_terminal in etats:
                automate['terminal_states'].append(etat)
                break

    # Mise à jour de l'automate avec les nouveaux états et transitions
    automate['num_states'] = len(nouveaux_etats)
    automate['init_states'] = [nouvel_etat_initial]
    automate['transitions'] = nouveaux_transitions
    automate['num_transitions'] = len(nouveaux_transitions)


    # Initialisation de la liste des états
    automate['states'] = []

    # Parcourir les nouveaux états créés lors de la déterminisation
    for etat, _ in nouveaux_etats.items():
        # Ajouter chaque état à la liste des états
        automate['states'].append(etat)

    # Mettre à jour le nombre d'états dans l'automate
    automate['num_states'] = len(automate['states'])

    print("Automate déterminisé avec succès.")


def completer_automate(automate):
    alphabet = set(chr(ord('a') + i) for i in range(automate['alphabet_size']))
    etat_poubelle = 'P'  # État poubelle
    automate['num_states'] += 1  # Incrémenter le nombre d'états
    automate['states'].append(etat_poubelle)  # Ajouter l'état poubelle à la liste des états

    nouveaux_transitions = automate['transitions'][:]  # Copie des transitions existantes
    transitions_traitees = set()  # Ensemble pour stocker les transitions déjà traitées

    # Ajout des transitions vides pour chaque symbole manquant pour chaque état
    for state in automate['states']:
        transitions = {transition[1] for transition in automate['transitions'] if transition[0] == state}
        for symbol in alphabet:
            if symbol not in transitions:
                nouvelle_transition = (state, symbol, etat_poubelle)
                if nouvelle_transition not in transitions_traitees:
                    nouveaux_transitions.append(nouvelle_transition)
                    transitions_traitees.add(nouvelle_transition)

    # Ajout des transitions de l'état poubelle vers lui-même pour chaque symbole de l'alphabet
    for symbol in alphabet:
        nouvelle_transition = (etat_poubelle, symbol, etat_poubelle)
        if nouvelle_transition not in transitions_traitees:
            nouveaux_transitions.append(nouvelle_transition)
            transitions_traitees.add(nouvelle_transition)

    # Mise à jour de l'automate avec les nouvelles transitions
    automate['transitions'] = nouveaux_transitions
    automate['num_transitions'] = len(nouveaux_transitions)

    print("Automate complété avec succès.")