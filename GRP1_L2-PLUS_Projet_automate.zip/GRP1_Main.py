"""Code de LUCAS Elise, OUACHTAR Iman, BALTHAZAR Jérôme,
ETIEVANT Séverin, Fraccaro Xavier,
Groupe n°1, L2-PLUS"""


#importations de nos fonctions
from GRP1_determiner_completer import *
from GRP1_lire_afficher_automate import *
from GRP1_lire_mot_complementarisation import *
from GRP1_standardisation import *

# Main
choix = 0
automate = None
ADC = False
complementaire = False

while automate is None:
    print("choix de l'automate :")
    filename = choisir_fichier_texte()
    print("Lecture de l'automate à partir du fichier :", filename)
    automate = lire_automate(filename)

while choix != 6:
    print("\nMenu :")
    print("1. Choisir un autre automate")
    print("2. Standardiser l'automate")
    print("3. Déterminiser et/ou compléter l'automate")
    print("4. Reconnaissance des mots")
    print("5. Complémentarisation")
    print("6. Quitter")

    entree = input("Entrez votre choix : ")

    # Vérifier si l'entrée est un entier
    if entree.isdigit():
        choix = int(entree)
        if choix < 1 or choix > 6:
            print("Veuillez entrer un nombre entre 1 et 6.")
        else:
            if choix == 1:
                filename = choisir_fichier_texte()
                print("Lecture de l'automate à partir du fichier :", filename)
                automate = lire_automate(filename)
                complementaire = False
            elif choix == 2:
                if automate:
                    afficher_standardisation(automate)
            elif choix == 3:
                if automate:
                    determiniser_completer_automate(automate)
            elif choix == 4:
                if automate:
                    saisir_et_tester_mots(automate)
            elif choix == 5:
                if automate and not complementaire:
                    complementariser_automate(automate)
                    complementaire = True
                elif not automate:
                    print("Veuillez d'abord choisir un automate (option 1).")
                else:
                    print("L'automate est déjà complémentarisé, veuillez prendre l'option 4 pour faire la reconnaisance des mots.")
            elif choix == 6:
                print("Merci d'avoir utilisé le programme.")
    else:
        print("Veuillez entrer un nombre valide entre 1 et 6.")