"""Code de LUCAS Elise, OUACHTAR Iman, BALTHAZAR Jérôme,
ETIEVANT Séverin, Fraccaro Xavier,
Groupe n°1, L2-PLUS"""

#importations de nos fonctions
from GRP1_determiner_completer import *
from GRP1_lire_afficher_automate import *


def test_reconnaissance_mot(automate, mot):
    # Vérifier à partir de chaque état initial
    for etat_initial in automate['init_states']:
        if tester_mot_depuis_etat(automate, mot, etat_initial):
            return True
    return False

def tester_mot_depuis_etat(automate, mot, etat):
    # Fonction récursive pour tester la reconnaissance du mot à partir d'un état
    if mot == '':
        # Vérifier si l'état est terminal
        return etat in automate['terminal_states']

    # Obtenir les transitions possibles depuis l'état courant
    transitions = [(start, symbol, end) for (start, symbol, end) in automate['transitions'] if start == etat]

    # Tester chaque transition possible
    for start, symbol, end in transitions:
        if mot[0] == symbol:
            # Appel récursif pour tester le mot restant depuis l'état suivant
            if tester_mot_depuis_etat(automate, mot[1:], end):
                return True

    return False

def saisir_et_tester_mots(automate):
    mots = []
    while True:
        mot = input("Entrez un mot (ou 'q' pour terminer) : ")
        if mot == 'q':
            break
        mots.append(mot)
    tester_mots_depuis_etat(automate, mots)

def tester_mots_depuis_etat(automate, mots):
    for mot in mots:
        reconnu = test_reconnaissance_mot(automate, mot)
        print(f"Le mot '{mot}' est {'reconnu' if reconnu else 'non reconnu'} par l'automate.")

def complementariser_automate(automate):
    # Vérifier si l'automate est déterministe et complet
    determiniser_completer_automate(automate)

    # Examiner tous les états pour déterminer les états terminaux et non terminaux
    etats_terminaux = []
    etats_non_terminaux = []
    for etat in automate['states']:
        if etat in automate['terminal_states']:
            etats_terminaux.append(etat)
        else:
            etats_non_terminaux.append(etat)

    # Échanger les états terminaux et non terminaux
    automate['terminal_states'] = etats_non_terminaux

    afficher_automate(automate)
    print("Langage complété avec succès.")
    afficher_tableau_automate(automate)

    # Test de reconnaissance de mots avec le nouvel automate
    saisir_et_tester_mots(automate)